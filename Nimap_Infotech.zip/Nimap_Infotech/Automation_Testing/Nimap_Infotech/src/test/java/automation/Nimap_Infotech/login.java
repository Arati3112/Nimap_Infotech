package automation.Nimap_Infotech;

import org.openqa.selenium.By;
import org.testng.annotations.Test;


public class login extends launch
{
	@Test(priority=1)
	void ragistration() throws InterruptedException
	{
         driver.findElement(By.xpath("/html/body/kt-auth/div/div/div[2]/kt-login/div[1]/a")).click();
         driver.findElement(By.xpath("/html/body/kt-auth/div/div/div[2]/kt-register/div/div/form/div[1]/mat-form-field/div/div[1]/div/input")).sendKeys("aratii");
         driver.findElement(By.xpath("/html/body/kt-auth/div/div/div[2]/kt-register/div/div/form/div[3]/mat-form-field/div/div[1]/div/input")).sendKeys("1234567890");
         //driver.findElement(By.xpath("//*[@id=\"mat-input-0\"]")).sendKeys("arati");
         driver.findElement(By.xpath("/html/body/kt-auth/div/div/div[2]/kt-register/div/div/form/div[4]/mat-form-field/div/div[1]/div/input")).sendKeys("waghmarearati6@gmail.com");
         //driver.findElement(By.xpath("/html/body/kt-auth/div/div/div[2]/kt-register/div/div/form/kt-captcha/div/div/form/input")).sendKeys("E5DIL3");
        Thread.sleep(10000);
         driver.findElement(By.id("kt_login_signin_submit")).click();
         //driver.close();
         
         
      }
	@Test(priority=2)
	void sign_in() throws InterruptedException
	{
		Thread.sleep(10000);
		//OTP will not received fast in Gmail
		//driver.findElement(By.xpath("/html/body/kt-auth/div/div/div[2]/kt-reset-password/div/div/form/div[1]/mat-form-field/div/div[1]/div/input")).sendKeys("7885");

		driver.findElement(By.xpath("/html/body/kt-auth/div/div/div[2]/kt-reset-password/div/div/form/div[2]/mat-form-field/div/div[1]/div/input")).sendKeys("arati@123");
         driver.findElement(By.xpath("//input[@placeholder='Confirm Password']")).sendKeys("arati@123");
         //driver.findElement(By.id("kt_login_signin_submit")).click();
         driver.findElement(By.xpath("/html/body/kt-auth/div/div/div[2]/kt-reset-password/div/div/form/div[4]/button[1]")).click();
	}
//	@Test(priority=3)
//	void login() throws InterruptedException 
//	{
//		driver.findElement(By.xpath("/html/body/kt-auth/div/div/div[2]/kt-login/div[2]/div/form/div[1]/mat-form-field/div/div[1]/div/input")).sendKeys("8793424501");
//		driver.findElement(By.xpath("//input[@placeholder='Password']")).sendKeys("arati@123");
//        Thread.sleep(10000);
//        driver.findElement(By.xpath("/html/body/kt-auth/div/div/div[2]/kt-login/div[2]/div/form/div[4]/button[2]")).click();

//}
	
}
